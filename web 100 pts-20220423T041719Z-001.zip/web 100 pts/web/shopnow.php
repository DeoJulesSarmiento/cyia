<?php
	include_once 'header1.php';
?>
<br><br>

<h2 class="title"> Sale up to 50% OFF </h2>


<div class="categories">

	<div class="small-container">
		<div class="row">
			<div class="col-4">
				<img src="pic/mba7.jpg" alt="">
			
			</div>

			<div class="col-4">
				<img src="pic/mba9.jpg" alt="">
			
			</div>

			<div class="col-4">
				<img src="pic/top1.png" alt="">
			</div>



            <div class="col-4">
				<img src="pic/mba8.jpg" alt="">
				
			</div>

            <div class="col-4">
				<img src="pic/ring1.jpg" alt="">
			
			</div>

            <div class="col-4">
				<img src="pic/nec3.jpg" alt="">
				
			</div>

			<div class="col-4">
				<img src="pic/r5.jpeg" alt="">
			
			</div>
			
			<div class="col-4">
				<img src="pic/s1.jpeg" alt="">
			
			</div>

			
		
		
		
    
			
		</div>

</div>

</div>

		<div class="footer">

		<div class="container">

			<div class="row">

<?php
	include_once 'footer.php';
?>
    