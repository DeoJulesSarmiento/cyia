


<div class="footer-col-2">
					<h3> About Us </h3>
					<p>Mba shop was established last August 2020. <br> It was named after the initials of the owner, April Bertonel Moog. 
					
				
					<br><br> CYIA Jewelry is a progressive, elegant and classic jewelry brand for men and women owned by Mia Mulingbayan. <br>

					<br>The mission of our online shop is simple. We are dedicated to bring you the newest and coolest classic pieces 
					at cheap rates. <br> The coolest and affordable accesories & trendy tops at our online retail shop
					can make you switch your heads everywhere you go. 
					</p>

				</div>

			
				<div class="footer-col-4">
					
					<h3>Follow Us</h3>
						
						<ul>
							<li><a href="https://www.facebook.com/mbashop-106323227866323">Facebook</a></li>
							<li><a href="https://www.instagram.com/cyia.ph">Instagram</a></li>
						
						</ul>

				</div>


			</div>
		

			</div>

			<hr>
			<p class="Copyright">Copyright 2021 </p>

		</div>

	</div>







</body>
</html>