<?php
	include_once 'header1.php';
?>
<br><br>

<h2 class="title"> Rings Collection</h2>


<div class="categories">
		<div class="small-container">
		<div class="row">
			<div class="col-3">
				<img src="pic/r8.jpeg" alt="">
			
			</div>

			<div class="col-3">
				<img src="pic/r6.jpeg" alt="">
			
			</div>

			<div class="col-3">
				<img src="pic/ring3.jpg" alt="">
			</div>



            <div class="col-3">
				<img src="pic/r5.jpeg" alt="">
				
			</div>

            <div class="col-3">
				<img src="pic/ring1.jpg" alt="">
			
			</div>

            <div class="col-3">
				<img src="pic/r4.jpeg" alt="">
				
		</div>

    <div class="page-btn">
        <span><a href="discover1.php">1</a></span>
		<span><a href="discover2.php">2</a></span>
		<span><a href="discover3.php">3</a></span>
		<span>&#8594 </span>
		</div>
			
		</div>

</div>


<div class="footer">

<div class="container">

    <div class="row">

<?php
include_once 'footer.php';
?>


    