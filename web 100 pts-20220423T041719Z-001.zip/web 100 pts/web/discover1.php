<?php
	include_once 'header1.php';
?>
<br><br>

<h2 class="title"> Necklace Collection</h2>


<div class="categories">
		<div class="small-container">
		<div class="row">
			<div class="col-3">
				<img src="pic/nec6.jpg" alt="">
			</div>

			<div class="col-3">
				<img src="pic/nec2.jpg" alt="">
			</div>

			<div class="col-3">
				<img src="pic/nec4.jpg" alt="">
			</div>



            <div class="col-3">
				<img src="pic/nec5.jpg" alt="">
				
			</div>

            <div class="col-3">
				<img src="pic/zxc.jpg" alt="">
			
			</div>

            <div class="col-3">
				<img src="pic/nec7.jpg" alt="">
				
		</div>

    <div class="page-btn">
    <span><a href="discover1.php">1</a></span>
    <span><a href="discover2.php">2</a></span>
    <span><a href="discover3.php">3</a></span>
    <span>&#8594 </span>
    </div>
			
		</div>

</div>

</div>

<div class="footer">

<div class="container">

    <div class="row">

<?php
include_once 'footer.php';
?>


    