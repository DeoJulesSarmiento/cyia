
<?php
	include_once 'header1.php';
?>

<div class="heads">
	
		<h1> Flaunt Your Own Sparkle</h1>

		<div>
			<a href="shopnow.php" class="btn">Shop Now</a>
		</div>
		
	</div> 
 

		<div class="categories">
		<div class="small-container">
		<div class="row">
			<div class="col-3">
				<img src="pic/neckk.jpeg" alt="">
				<h1> Necklaces</h1>
				<a href="discover1.php" class="btnn">Discover</a>
			</div>

			<div class="col-3">
				<img src="pic/trendyy.jpg" alt="">
				<h1> Trendy Tops</h1>
				<a href="discover2.php" class="btnn">Discover</a>
			</div>

			<div class="col-3">
				<img src="pic/r6.jpeg" alt="">
				<h1> Rings</h1>
				<a href="discover3.php" class="btnn">Discover</a>
			</div>
		</div>
			
		</div>
	</div>

	<div class="heads1">
	
		<h1> Sale</h1>

		<div>
			<a href="#" class="btn">Discover</a>
		</div>
		
	</div> 

	<!--featured products-->
	<div class="small-container">

			<h2 class="title"> Trending Now </h2>

			<div class="row">
				<div class="col-4">
					<img src="pic/prod_2.jpg">
					<h4>Niall Bangle</h4>
					<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>350 php</p>
				</div>
				<div class="col-4">
					<img src="pic/prod_1.jpg">
					<h4>ALEX Layered Necklace</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>250.00</p>
				</div>
				<div class="col-4">
					<img src="pic/prod_3.jpg">
					<h4>Marbella in Gold</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>120.00</p>
				</div>
				<div class="col-4">
					<img src="pic/ring.jpg">
					<h4>Couple Ring</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>350 php</p>
				</div>
				<div class="col-4">
					<img src="pic/mba1.jpg">
					<h4>ZARA One-Sided Top</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>140.00</p>
				</div>
				<div class="col-4">
					<img src="pic/mba2.jpg">
					<h4>BERSKA Lettuce Top</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>180.00</p>
				</div>
				<div class="col-4">
					<img src="pic/mba3.jpg">
					<h4>ZARA Racerback Top</h4>
						<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
					</div>
					<p>150.00</p>
				</div>
				<div class="col-4">
					<img src="pic/mba4.jpg">
					<h4>MANGO Buttondown</h4>
				<div class="rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o"></i>
				</div>
					<p>180.00</p>
				</div>

			</div>

		</div>

		<div class="ceo">
			<div class="small-container">

				<h2 class="title"> Customer Service </h2>

				
				<div class="row">
					<div class="col-3">
						<img src="pic/cs1.jpg">
				<h3>April Moog</h3>
						<p>Admin and owner of mba shop
						</p>
				
				
					</div>

						<div class="col-3">
				
				<img src="pic/cs2.jpg">
				<h3>Deo Sarmiento</h3>
						<p>Supervisor
						</p>
			
					</div>

						<div class="col-3">
						<img src="pic/mia.jpg">
				<h3>Mia Mulingbayan</h3>
						<p>Admin and owner cyia
						</p>
			
			
					</div>
				</div>
			</div>
		</div>
	
	


			<div class="brands">
				<div class="small-container">

					<h2 class="title"> New Collections </h2>

					<div class="row">
						<div class="col-5">
							<img src="pic/pearl.jpeg">
						</div>
						<div class="col-5">
							<img src="pic/ruched.jpg">
						</div>
						<div class="col-5">
							<img src="pic/hoops.jpg">
						</div>
						<div class="col-5">
							<img src="pic/snap.jpg">
						</div>
						<div class="col-5">
							<img src="pic/hoops1.jpg">
						</div>
					</div>
				</div>
			</div>

			<div class="footer">

		<div class="container">

			<div class="row">

<?php
	include_once 'footer.php';
?>


			